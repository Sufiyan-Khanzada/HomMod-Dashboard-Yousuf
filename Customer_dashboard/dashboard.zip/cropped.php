<!-- <!DOCTYPE html><html class="no-js" lang="en" dir="ltr" data-theme="dark">
Mirrored from pixelwibes.com/template/ebazar/html/dist/cropped.jpg by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Nov 2022 18:18:46 GMT
<head>
  <meta charset="utf-8">
  <title>PixelWibes</title>      
  <base >
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="http://pixelwibes.com/favicon.ico">           
<style>@import"https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900&amp;display=swap";@charset "UTF-8";:root{--bs-blue:#0d6efd;--bs-indigo:#6610f2;--bs-purple:#6f42c1;--bs-pink:#d63384;--bs-red:#dc3545;--bs-orange:#fd7e14;--bs-yellow:#ffc107;--bs-green:#198754;--bs-teal:#20c997;--bs-cyan:#0dcaf0;--bs-white:#fff;--bs-gray:#6c757d;--bs-gray-dark:#343a40;--bs-gray-100:#f8f9fa;--bs-gray-200:#e9ecef;--bs-gray-300:#dee2e6;--bs-gray-400:#ced4da;--bs-gray-500:#adb5bd;--bs-gray-600:#6c757d;--bs-gray-700:#495057;--bs-gray-800:#343a40;--bs-gray-900:#212529;--bs-primary:#0d6efd;--bs-secondary:#6c757d;--bs-success:#198754;--bs-info:#0dcaf0;--bs-warning:#ffc107;--bs-danger:#dc3545;--bs-light:#f8f9fa;--bs-dark:#212529;--bs-primary-rgb:13, 110, 253;--bs-secondary-rgb:108, 117, 125;--bs-success-rgb:25, 135, 84;--bs-info-rgb:13, 202, 240;--bs-warning-rgb:255, 193, 7;--bs-danger-rgb:220, 53, 69;--bs-light-rgb:248, 249, 250;--bs-dark-rgb:33, 37, 41;--bs-white-rgb:255, 255, 255;--bs-black-rgb:0, 0, 0;--bs-body-color-rgb:33, 37, 41;--bs-body-bg-rgb:255, 255, 255;--bs-font-sans-serif:system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji";--bs-font-monospace:SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;--bs-gradient:linear-gradient(180deg, rgba(255, 255, 255, .15), rgba(255, 255, 255, 0));--bs-body-font-family:var(--bs-font-sans-serif);--bs-body-font-size:1rem;--bs-body-font-weight:400;--bs-body-line-height:1.5;--bs-body-color:#212529;--bs-body-bg:#fff}*,*:before,*:after{box-sizing:border-box}@media (prefers-reduced-motion: no-preference){:root{scroll-behavior:smooth}}body{margin:0;font-family:var(--bs-body-font-family);font-size:var(--bs-body-font-size);font-weight:var(--bs-body-font-weight);line-height:var(--bs-body-line-height);color:var(--bs-body-color);text-align:var(--bs-body-text-align);background-color:var(--bs-body-bg);-webkit-text-size-adjust:100%;-webkit-tap-highlight-color:rgba(0,0,0,0)}:root{--dark-color:#323A45;--color-fff:#FFFFFF;--color-100:#F0F0F0;--color-200:#EEEEEE;--color-300:#E0E0E0;--color-400:#BDBDBD;--color-500:#555555;--color-600:#757575;--color-700:#616161;--color-800:#424242;--color-900:#212121;--color-000:#000000;--border-color:#f4eefb;--card-color:#ffffff;--body-color:#f9fbfd;--white-color:#ffffff;--sidebar-color:#fcfcfc;--text-color:#000000;--title-color:#000000;--svg-color:#EA5039;--hc-font-color:#555555;--hc-bg-color:#f0f0f0;--borderColor08:rgba(0, 0, 0, .03);--borderColor03:rgba(0, 0, 0, .02);--borderColor1:rgba(0, 0, 0, .03);--borderColor4:rgba(0, 0, 0, .2);--primary-color:#EA5039;--secondary-color:#E63354;--second-color:#fa7e7e;--option-color1:#6aab9c;--option-color2:#EAA839;--option-color3:#eff2f9;--option-color4:#4D6E94;--option-color5:#81A1CA;--primary-gradient:linear-gradient(145deg, var(--secondary-color), var(--option-color2))}[data-theme=dark]{--dark-color:#323A45;--color-fff:#000000;--color-100:#212121;--color-200:#424242;--color-300:#616161;--color-400:#757575;--color-500:#8f8f8f;--color-600:#BDBDBD;--color-700:#E0E0E0;--color-800:#EEEEEE;--color-900:#F0F0F0;--color-000:#FFFFFF;--border-color:#353535;--card-color:#262727;--body-color:#111111;--white-color:#ffffff;--sidebar-color:#fcfcfc;--text-color:#FFFFFF;--title-color:#FFFFFF;--svg-color:#EA5039;--hc-font-color:#555555;--hc-bg-color:#f0f0f0;--borderColor08:rgba(255, 255, 255, .06);--borderColor03:rgba(255, 255, 255, .02);--borderColor1:rgba(255, 255, 255, .05);--borderColor4:rgba(255, 255, 255, .2);--primary-color:#fbae24;--secondary-color:#E63354;--second-color:#fa7e7e;--option-color1:#6aab9c;--option-color2:#EAA839;--option-color3:#1a1a1a;--option-color4:#4D6E94;--option-color5:#81A1CA;--primary-gradient:linear-gradient(145deg, var(--secondary-color), var(--option-color2))}html{scroll-behavior:smooth}body{font-family:Poppins,sans-serif;font-weight:400;font-style:normal;color:var(--text-color);overflow-x:hidden;position:relative;background-color:var(--body-color)}*{margin:0;padding:0;box-sizing:border-box}</style><link rel="stylesheet" href="../../../../../www.pixelwibes.com/styles.b4c617471c876b8f.css" media="print" onload="this.media='all'"><noscript><link rel="stylesheet" href="../../../../../www.pixelwibes.com/styles.b4c617471c876b8f.css"></noscript></head>
<body>     
  <app-root></app-root>          
<script src="../../../../../www.pixelwibes.com/runtime.d65e8170c6d7ecaf.js" type="module"></script><script src="../../../../../www.pixelwibes.com/polyfills.68d635b615eb8f25.js" type="module"></script><script src="../../../../../www.pixelwibes.com/scripts.09634b4547891c9e.js" defer></script><script src="../../../../../www.pixelwibes.com/main.89941581323970fc.js" type="module"></script>    
      
Start of Tawk.to Script
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/6051a040f7ce18270930e55a/1f55i240o';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
End of Tawk.to Script-->
                     

</body>
<!-- Mirrored from pixelwibes.com/template/ebazar/html/dist/cropped.jpg by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 02 Nov 2022 18:18:50 GMT -->
</html> -->