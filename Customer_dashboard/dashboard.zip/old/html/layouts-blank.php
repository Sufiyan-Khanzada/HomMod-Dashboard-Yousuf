<?php include 'header.php'; ?>
<?php include 'navigation.php'; ?>

    <h4 class="fw-bold p-4">Blank Page</h4>

    <!-- / Content -->
    
<?php include 'footer.php'; ?>