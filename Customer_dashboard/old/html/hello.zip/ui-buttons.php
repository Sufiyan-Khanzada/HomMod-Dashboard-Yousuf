<?php include 'header.php'; ?>
<?php include 'navigation.php'; ?>

    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar">
      <div class="layout-container">
        <!-- Menu -->

        <aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
          <div class="app-brand demo">
            <a href="index.html" class="app-brand-link">
              <span class="app-brand-logo demo">
                <svg
                  width="25"
                  viewBox="0 0 25 42"
                  version="1.1"
                  xmlns="http://www.w3.org/2000/svg"
                  xmlns:xlink="http://www.w3.org/1999/xlink"
                >
                  <defs>
                    <path
                      d="M13.7918663,0.358365126 L3.39788168,7.44174259 C0.566865006,9.69408886 -0.379795268,12.4788597 0.557900856,15.7960551 C0.68998853,16.2305145 1.09562888,17.7872135 3.12357076,19.2293357 C3.8146334,19.7207684 5.32369333,20.3834223 7.65075054,21.2172976 L7.59773219,21.2525164 L2.63468769,24.5493413 C0.445452254,26.3002124 0.0884951797,28.5083815 1.56381646,31.1738486 C2.83770406,32.8170431 5.20850219,33.2640127 7.09180128,32.5391577 C8.347334,32.0559211 11.4559176,30.0011079 16.4175519,26.3747182 C18.0338572,24.4997857 18.6973423,22.4544883 18.4080071,20.2388261 C17.963753,17.5346866 16.1776345,15.5799961 13.0496516,14.3747546 L10.9194936,13.4715819 L18.6192054,7.984237 L13.7918663,0.358365126 Z"
                      id="path-1"
                    ></path>
                    <path
                      d="M5.47320593,6.00457225 C4.05321814,8.216144 4.36334763,10.0722806 6.40359441,11.5729822 C8.61520715,12.571656 10.0999176,13.2171421 10.8577257,13.5094407 L15.5088241,14.433041 L18.6192054,7.984237 C15.5364148,3.11535317 13.9273018,0.573395879 13.7918663,0.358365126 C13.5790555,0.511491653 10.8061687,2.3935607 5.47320593,6.00457225 Z"
                      id="path-3"
                    ></path>
                    <path
                      d="M7.50063644,21.2294429 L12.3234468,23.3159332 C14.1688022,24.7579751 14.397098,26.4880487 13.008334,28.506154 C11.6195701,30.5242593 10.3099883,31.790241 9.07958868,32.3040991 C5.78142938,33.4346997 4.13234973,34 4.13234973,34 C4.13234973,34 2.75489982,33.0538207 2.37032616e-14,31.1614621 C-0.55822714,27.8186216 -0.55822714,26.0572515 -4.05231404e-15,25.8773518 C0.83734071,25.6075023 2.77988457,22.8248993 3.3049379,22.52991 C3.65497346,22.3332504 5.05353963,21.8997614 7.50063644,21.2294429 Z"
                      id="path-4"
                    ></path>
                    <path
                      d="M20.6,7.13333333 L25.6,13.8 C26.2627417,14.6836556 26.0836556,15.9372583 25.2,16.6 C24.8538077,16.8596443 24.4327404,17 24,17 L14,17 C12.8954305,17 12,16.1045695 12,15 C12,14.5672596 12.1403557,14.1461923 12.4,13.8 L17.4,7.13333333 C18.0627417,6.24967773 19.3163444,6.07059163 20.2,6.73333333 C20.3516113,6.84704183 20.4862915,6.981722 20.6,7.13333333 Z"
                      id="path-5"
                    ></path>
                  </defs>
                  <g id="g-app-brand" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                    <g id="Brand-Logo" transform="translate(-27.000000, -15.000000)">
                      <g id="Icon" transform="translate(27.000000, 15.000000)">
                        <g id="Mask" transform="translate(0.000000, 8.000000)">
                          <mask id="mask-2" fill="white">
                            <use xlink:href="#path-1"></use>
                          </mask>
                          <use fill="#696cff" xlink:href="#path-1"></use>
                          <g id="Path-3" mask="url(#mask-2)">
                            <use fill="#696cff" xlink:href="#path-3"></use>
                            <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-3"></use>
                          </g>
                          <g id="Path-4" mask="url(#mask-2)">
                            <use fill="#696cff" xlink:href="#path-4"></use>
                            <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-4"></use>
                          </g>
                        </g>
                        <g
                          id="Triangle"
                          transform="translate(19.000000, 11.000000) rotate(-300.000000) translate(-19.000000, -11.000000) "
                        >
                          <use fill="#696cff" xlink:href="#path-5"></use>
                          <use fill-opacity="0.2" fill="#FFFFFF" xlink:href="#path-5"></use>
                        </g>
                      </g>
                    </g>
                  </g>
                </svg>
              </span>
              <span class="app-brand-text demo menu-text fw-bolder ms-2">Sneat</span>
            </a>

            <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
              <i class="bx bx-chevron-left bx-sm align-middle"></i>
            </a>
          </div>

          <div class="menu-inner-shadow"></div>

          <ul class="menu-inner py-1">
            <!-- Dashboard -->
            <li class="menu-item">
              <a href="index.html" class="menu-link">
                <i class="menu-icon tf-icons bx bx-home-circle"></i>
                <div data-i18n="Analytics">Dashboard</div>
              </a>
            </li>

            <!-- Layouts -->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-layout"></i>
                <div data-i18n="Layouts">Layouts</div>
              </a>

              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="layouts-without-menu.html" class="menu-link">
                    <div data-i18n="Without menu">Without menu</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="layouts-without-navbar.html" class="menu-link">
                    <div data-i18n="Without navbar">Without navbar</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="layouts-container.html" class="menu-link">
                    <div data-i18n="Container">Container</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="layouts-fluid.html" class="menu-link">
                    <div data-i18n="Fluid">Fluid</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="layouts-blank.html" class="menu-link">
                    <div data-i18n="Blank">Blank</div>
                  </a>
                </li>
              </ul>
            </li>

            <li class="menu-header small text-uppercase">
              <span class="menu-header-text">Pages</span>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-dock-top"></i>
                <div data-i18n="Account Settings">Account Settings</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="pages-account-settings-account.html" class="menu-link">
                    <div data-i18n="Account">Account</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="pages-account-settings-notifications.html" class="menu-link">
                    <div data-i18n="Notifications">Notifications</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="pages-account-settings-connections.html" class="menu-link">
                    <div data-i18n="Connections">Connections</div>
                  </a>
                </li>
              </ul>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-lock-open-alt"></i>
                <div data-i18n="Authentications">Authentications</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="auth-login-basic.html" class="menu-link" target="_blank">
                    <div data-i18n="Basic">Login</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="auth-register-basic.html" class="menu-link" target="_blank">
                    <div data-i18n="Basic">Register</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="auth-forgot-password-basic.html" class="menu-link" target="_blank">
                    <div data-i18n="Basic">Forgot Password</div>
                  </a>
                </li>
              </ul>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-cube-alt"></i>
                <div data-i18n="Misc">Misc</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="pages-misc-error.html" class="menu-link">
                    <div data-i18n="Error">Error</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="pages-misc-under-maintenance.html" class="menu-link">
                    <div data-i18n="Under Maintenance">Under Maintenance</div>
                  </a>
                </li>
              </ul>
            </li>
            <!-- Components -->
            <li class="menu-header small text-uppercase"><span class="menu-header-text">Components</span></li>
            <!-- Cards -->
            <li class="menu-item">
              <a href="cards-basic.html" class="menu-link">
                <i class="menu-icon tf-icons bx bx-collection"></i>
                <div data-i18n="Basic">Cards</div>
              </a>
            </li>
            <!-- User interface -->
            <li class="menu-item active open">
              <a href="javascript:void(0)" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-box"></i>
                <div data-i18n="User interface">User interface</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="ui-accordion.html" class="menu-link">
                    <div data-i18n="Accordion">Accordion</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-alerts.html" class="menu-link">
                    <div data-i18n="Alerts">Alerts</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-badges.html" class="menu-link">
                    <div data-i18n="Badges">Badges</div>
                  </a>
                </li>
                <li class="menu-item active">
                  <a href="ui-buttons.html" class="menu-link">
                    <div data-i18n="Buttons">Buttons</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-carousel.html" class="menu-link">
                    <div data-i18n="Carousel">Carousel</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-collapse.html" class="menu-link">
                    <div data-i18n="Collapse">Collapse</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-dropdowns.html" class="menu-link">
                    <div data-i18n="Dropdowns">Dropdowns</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-footer.html" class="menu-link">
                    <div data-i18n="Footer">Footer</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-list-groups.html" class="menu-link">
                    <div data-i18n="List Groups">List groups</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-modals.html" class="menu-link">
                    <div data-i18n="Modals">Modals</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-navbar.html" class="menu-link">
                    <div data-i18n="Navbar">Navbar</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-offcanvas.html" class="menu-link">
                    <div data-i18n="Offcanvas">Offcanvas</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-pagination-breadcrumbs.html" class="menu-link">
                    <div data-i18n="Pagination &amp; Breadcrumbs">Pagination &amp; Breadcrumbs</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-progress.html" class="menu-link">
                    <div data-i18n="Progress">Progress</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-spinners.html" class="menu-link">
                    <div data-i18n="Spinners">Spinners</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-tabs-pills.html" class="menu-link">
                    <div data-i18n="Tabs &amp; Pills">Tabs &amp; Pills</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-toasts.html" class="menu-link">
                    <div data-i18n="Toasts">Toasts</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-tooltips-popovers.html" class="menu-link">
                    <div data-i18n="Tooltips & Popovers">Tooltips &amp; popovers</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="ui-typography.html" class="menu-link">
                    <div data-i18n="Typography">Typography</div>
                  </a>
                </li>
              </ul>
            </li>

            <!-- Extended components -->
            <li class="menu-item">
              <a href="javascript:void(0)" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-copy"></i>
                <div data-i18n="Extended UI">Extended UI</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="extended-ui-perfect-scrollbar.html" class="menu-link">
                    <div data-i18n="Perfect Scrollbar">Perfect scrollbar</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="extended-ui-text-divider.html" class="menu-link">
                    <div data-i18n="Text Divider">Text Divider</div>
                  </a>
                </li>
              </ul>
            </li>

            <li class="menu-item">
              <a href="icons-boxicons.html" class="menu-link">
                <i class="menu-icon tf-icons bx bx-crown"></i>
                <div data-i18n="Boxicons">Boxicons</div>
              </a>
            </li>

            <!-- Forms & Tables -->
            <li class="menu-header small text-uppercase"><span class="menu-header-text">Forms &amp; Tables</span></li>
            <!-- Forms -->
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-detail"></i>
                <div data-i18n="Form Elements">Form Elements</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="forms-basic-inputs.html" class="menu-link">
                    <div data-i18n="Basic Inputs">Basic Inputs</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="forms-input-groups.html" class="menu-link">
                    <div data-i18n="Input groups">Input groups</div>
                  </a>
                </li>
              </ul>
            </li>
            <li class="menu-item">
              <a href="javascript:void(0);" class="menu-link menu-toggle">
                <i class="menu-icon tf-icons bx bx-detail"></i>
                <div data-i18n="Form Layouts">Form Layouts</div>
              </a>
              <ul class="menu-sub">
                <li class="menu-item">
                  <a href="form-layouts-vertical.html" class="menu-link">
                    <div data-i18n="Vertical Form">Vertical Form</div>
                  </a>
                </li>
                <li class="menu-item">
                  <a href="form-layouts-horizontal.html" class="menu-link">
                    <div data-i18n="Horizontal Form">Horizontal Form</div>
                  </a>
                </li>
              </ul>
            </li>
            <!-- Tables -->
            <li class="menu-item">
              <a href="tables-basic.html" class="menu-link">
                <i class="menu-icon tf-icons bx bx-table"></i>
                <div data-i18n="Tables">Tables</div>
              </a>
            </li>
            <!-- Misc -->
            <li class="menu-header small text-uppercase"><span class="menu-header-text">Misc</span></li>
            <li class="menu-item">
              <a
                href="https://github.com/themeselection/sneat-html-admin-template-free/issues"
                target="_blank"
                class="menu-link"
              >
                <i class="menu-icon tf-icons bx bx-support"></i>
                <div data-i18n="Support">Support</div>
              </a>
            </li>
            <li class="menu-item">
              <a
                href="https://themeselection.com/demo/sneat-bootstrap-html-admin-template/documentation/"
                target="_blank"
                class="menu-link"
              >
                <i class="menu-icon tf-icons bx bx-file"></i>
                <div data-i18n="Documentation">Documentation</div>
              </a>
            </li>
          </ul>
        </aside>
        <!-- / Menu -->

        <!-- Layout container -->
        <div class="layout-page">
          <!-- Navbar -->

          <nav
            class="layout-navbar container-xxl navbar navbar-expand-xl navbar-detached align-items-center bg-navbar-theme"
            id="layout-navbar"
          >
            <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
              <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
                <i class="bx bx-menu bx-sm"></i>
              </a>
            </div>

            <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
              <!-- Search -->
              <div class="navbar-nav align-items-center">
                <div class="nav-item d-flex align-items-center">
                  <i class="bx bx-search fs-4 lh-0"></i>
                  <input
                    type="text"
                    class="form-control border-0 shadow-none"
                    placeholder="Search..."
                    aria-label="Search..."
                  />
                </div>
              </div>
              <!-- /Search -->

              <ul class="navbar-nav flex-row align-items-center ms-auto">
                <!-- Place this tag where you want the button to render. -->
                <li class="nav-item lh-1 me-3">
                  <a
                    class="github-button"
                    href="https://github.com/themeselection/sneat-html-admin-template-free"
                    data-icon="octicon-star"
                    data-size="large"
                    data-show-count="true"
                    aria-label="Star themeselection/sneat-html-admin-template-free on GitHub"
                    >Star</a
                  >
                </li>

                <!-- User -->
                <li class="nav-item navbar-dropdown dropdown-user dropdown">
                  <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                      <img src="../assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                    </div>
                  </a>
                  <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                      <a class="dropdown-item" href="#">
                        <div class="d-flex">
                          <div class="flex-shrink-0 me-3">
                            <div class="avatar avatar-online">
                              <img src="../assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                            </div>
                          </div>
                          <div class="flex-grow-1">
                            <span class="fw-semibold d-block">John Doe</span>
                            <small class="text-muted">Admin</small>
                          </div>
                        </div>
                      </a>
                    </li>
                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        <i class="bx bx-user me-2"></i>
                        <span class="align-middle">My Profile</span>
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        <i class="bx bx-cog me-2"></i>
                        <span class="align-middle">Settings</span>
                      </a>
                    </li>
                    <li>
                      <a class="dropdown-item" href="#">
                        <span class="d-flex align-items-center align-middle">
                          <i class="flex-shrink-0 bx bx-credit-card me-2"></i>
                          <span class="flex-grow-1 align-middle">Billing</span>
                          <span class="flex-shrink-0 badge badge-center rounded-pill bg-danger w-px-20 h-px-20">4</span>
                        </span>
                      </a>
                    </li>
                    <li>
                      <div class="dropdown-divider"></div>
                    </li>
                    <li>
                      <a class="dropdown-item" href="auth-login-basic.html">
                        <i class="bx bx-power-off me-2"></i>
                        <span class="align-middle">Log Out</span>
                      </a>
                    </li>
                  </ul>
                </li>
                <!--/ User -->
              </ul>
            </div>
          </nav>

          <!-- / Navbar -->

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <h4 class="fw-bold py-3 mb-4">
                <span class="text-muted fw-light">UI elements /</span>
                Buttons
              </h4>

              <div class="row">
                <!-- Basic Buttons -->

                <div class="col-12">
                  <div class="card mb-4">
                    <h5 class="card-header">Basic Buttons</h5>
                    <div class="card-body">
                      <small class="text-light fw-semibold">Default</small>
                      <div class="demo-inline-spacing">
                        <button type="button" class="btn btn-primary">Primary</button>
                        <button type="button" class="btn btn-secondary">Secondary</button>
                        <button type="button" class="btn btn-success">Success</button>
                        <button type="button" class="btn btn-danger">Danger</button>
                        <button type="button" class="btn btn-warning">Warning</button>
                        <button type="button" class="btn btn-info">Info</button>
                        <button type="button" class="btn btn-dark">Dark</button>
                      </div>
                    </div>
                    <hr class="m-0" />
                    <div class="card-body">
                      <small class="text-light fw-semibold">Rounded</small>
                      <div class="demo-inline-spacing">
                        <button type="button" class="btn rounded-pill btn-primary">Primary</button>
                        <button type="button" class="btn rounded-pill btn-secondary">Secondary</button>
                        <button type="button" class="btn rounded-pill btn-success">Success</button>
                        <button type="button" class="btn rounded-pill btn-danger">Danger</button>
                        <button type="button" class="btn rounded-pill btn-warning">Warning</button>
                        <button type="button" class="btn rounded-pill btn-info">Info</button>
                        <button type="button" class="btn rounded-pill btn-dark">Dark</button>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Outline Buttons -->

                <div class="col-12">
                  <div class="card mb-4">
                    <h5 class="card-header">Outline Buttons</h5>
                    <div class="card-body">
                      <small class="text-light fw-semibold">Default</small>
                      <div class="demo-inline-spacing">
                        <button type="button" class="btn btn-outline-primary">Primary</button>
                        <button type="button" class="btn btn-outline-secondary">Secondary</button>
                        <button type="button" class="btn btn-outline-success">Success</button>
                        <button type="button" class="btn btn-outline-danger">Danger</button>
                        <button type="button" class="btn btn-outline-warning">Warning</button>
                        <button type="button" class="btn btn-outline-info">Info</button>
                        <button type="button" class="btn btn-outline-dark">Dark</button>
                      </div>
                    </div>
                    <hr class="m-0" />
                    <div class="card-body">
                      <small class="text-light fw-semibold">Rounded</small>
                      <div class="demo-inline-spacing">
                        <button type="button" class="btn rounded-pill btn-outline-primary">Primary</button>
                        <button type="button" class="btn rounded-pill btn-outline-secondary">Secondary</button>
                        <button type="button" class="btn rounded-pill btn-outline-success">Success</button>
                        <button type="button" class="btn rounded-pill btn-outline-danger">Danger</button>
                        <button type="button" class="btn rounded-pill btn-outline-warning">Warning</button>
                        <button type="button" class="btn rounded-pill btn-outline-info">Info</button>
                        <button type="button" class="btn rounded-pill btn-outline-dark">Dark</button>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Buttons with Icons -->

                <div class="col-12">
                  <div class="card mb-4">
                    <h5 class="card-header">Buttons with Icons</h5>
                    <div class="card-body">
                      <div class="row gy-3">
                        <div class="col-md-6">
                          <small class="text-light fw-semibold">Basic</small>
                          <div class="demo-inline-spacing">
                            <button type="button" class="btn btn-primary">
                              <span class="tf-icons bx bx-pie-chart-alt"></span>&nbsp; Primary
                            </button>
                            <button type="button" class="btn btn-secondary">
                              <span class="tf-icons bx bx-bell"></span>&nbsp; Secondary
                            </button>
                          </div>
                          <div class="demo-inline-spacing">
                            <button type="button" class="btn rounded-pill btn-primary">
                              <span class="tf-icons bx bx-pie-chart-alt"></span>&nbsp; Primary
                            </button>
                            <button type="button" class="btn rounded-pill btn-secondary">
                              <span class="tf-icons bx bx-bell"></span>&nbsp; Secondary
                            </button>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <small class="text-light fw-semibold">Outline</small>
                          <div class="demo-inline-spacing">
                            <button type="button" class="btn btn-outline-primary">
                              <span class="tf-icons bx bx-pie-chart-alt"></span>&nbsp; Primary
                            </button>
                            <button type="button" class="btn btn-outline-secondary">
                              <span class="tf-icons bx bx-bell"></span>&nbsp; Secondary
                            </button>
                          </div>
                          <div class="demo-inline-spacing">
                            <button type="button" class="btn rounded-pill btn-outline-primary">
                              <span class="tf-icons bx bx-pie-chart-alt"></span>&nbsp; Primary
                            </button>
                            <button type="button" class="btn rounded-pill btn-outline-secondary">
                              <span class="tf-icons bx bx-bell"></span>&nbsp; Secondary
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <hr class="m-0" />
                    <div class="card-body">
                      <div class="row gy-3">
                        <div class="col-md-6">
                          <small class="text-light fw-semibold">Basic</small>
                          <div class="demo-inline-spacing">
                            <button type="button" class="btn btn-icon btn-primary">
                              <span class="tf-icons bx bx-pie-chart-alt"></span>
                            </button>
                            <button type="button" class="btn btn-icon btn-secondary">
                              <span class="tf-icons bx bx-bell"></span>
                            </button>
                            <button type="button" class="btn rounded-pill btn-icon btn-primary">
                              <span class="tf-icons bx bx-pie-chart-alt"></span>
                            </button>
                            <button type="button" class="btn rounded-pill btn-icon btn-secondary">
                              <span class="tf-icons bx bx-bell"></span>
                            </button>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <small class="text-light fw-semibold">Outline</small>
                          <div class="demo-inline-spacing">
                            <button type="button" class="btn btn-icon btn-outline-primary">
                              <span class="tf-icons bx bx-pie-chart-alt"></span>
                            </button>
                            <button type="button" class="btn btn-icon btn-outline-secondary">
                              <span class="tf-icons bx bx-bell"></span>
                            </button>
                            <button type="button" class="btn rounded-pill btn-icon btn-outline-primary">
                              <span class="tf-icons bx bx-pie-chart-alt"></span>
                            </button>
                            <button type="button" class="btn rounded-pill btn-icon btn-outline-secondary">
                              <span class="tf-icons bx bx-bell"></span>
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Button Options -->
                <div class="col-12">
                  <div class="card mb-4">
                    <h5 class="card-header">Button Options</h5>
                    <div class="card-body">
                      <small class="text-light fw-semibold">Sizes</small>
                      <div class="demo-inline-spacing">
                        <button type="button" class="btn btn-xl btn-primary">Button xl</button>
                        <button type="button" class="btn btn-lg btn-primary">Button lg</button>
                        <button type="button" class="btn btn-primary">Button</button>
                        <button type="button" class="btn btn-sm btn-primary">Button sm</button>
                        <button type="button" class="btn btn-xs btn-primary">Button xs</button>
                      </div>
                    </div>
                    <hr class="m-0" />
                    <div class="card-body">
                      <small class="text-light fw-semibold">Buttons State</small>
                      <div class="demo-inline-spacing">
                        <button type="button" class="btn btn-primary">Normal</button>
                        <button type="button" class="btn btn-primary active">Active</button>
                        <button type="button" class="btn btn-primary" disabled>Disabled</button>
                      </div>
                    </div>
                    <hr class="m-0" />
                    <div class="card-body">
                      <small class="text-light fw-semibold">Block level buttons</small>
                      <div class="row mt-3">
                        <div class="d-grid gap-2 col-lg-6 mx-auto">
                          <button class="btn btn-primary btn-lg" type="button">Button</button>
                          <button class="btn btn-secondary btn-lg" type="button">Button</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Button Plugin -->
                <div class="col-12">
                  <div class="card mb-4">
                    <h5 class="card-header">Button Plugin</h5>
                    <div class="card-body">
                      <div class="row gy-3">
                        <div class="col-xl-3">
                          <div class="text-light small fw-semibold">Toggle states</div>
                          <div class="demo-vertical-spacing">
                            <button
                              type="button"
                              class="btn btn-primary d-block"
                              data-bs-toggle="button"
                              autocomplete="off"
                            >
                              Toggle button
                            </button>
                            <button
                              type="button"
                              class="btn btn-primary active d-block"
                              data-bs-toggle="button"
                              autocomplete="off"
                              aria-pressed="true"
                            >
                              Active toggle button
                            </button>
                            <button
                              type="button"
                              class="btn btn-primary d-block"
                              disabled
                              data-bs-toggle="button"
                              autocomplete="off"
                            >
                              Disabled toggle button
                            </button>
                          </div>
                        </div>
                        <div class="col-xl-3">
                          <div class="text-light small fw-semibold">Checkbox toggle buttons</div>
                          <div class="demo-vertical-spacing">
                            <div class="d-block">
                              <input type="checkbox" class="btn-check" id="btn-check" autocomplete="off" />
                              <label class="btn btn-primary" for="btn-check">Single toggle</label>
                            </div>
                            <div class="d-block">
                              <input type="checkbox" class="btn-check" id="btn-check-2" checked autocomplete="off" />
                              <label class="btn btn-primary" for="btn-check-2">Checked</label>
                            </div>
                            <div class="d-block">
                              <input type="checkbox" class="btn-check" id="btn-check-3" checked autocomplete="off" />
                              <label class="btn btn-primary" for="btn-check-3">Checked</label>
                            </div>
                          </div>
                        </div>
                        <div class="col-xl-6">
                          <div class="text-light small fw-semibold">Checkbox and radio</div>
                          <div class="demo-vertical-spacing">
                            <!-- Checkbox -->
                            <div class="btn-group" role="group" aria-label="Basic checkbox toggle button group">
                              <input type="checkbox" class="btn-check" id="btncheck1" checked autocomplete="off" />
                              <label class="btn btn-outline-primary" for="btncheck1">Checkbox 1 (pre-checked)</label>
                              <input type="checkbox" class="btn-check" id="btncheck2" autocomplete="off" />
                              <label class="btn btn-outline-primary" for="btncheck2">Checkbox 2</label>
                              <input type="checkbox" class="btn-check" id="btncheck3" autocomplete="off" />
                              <label class="btn btn-outline-primary" for="btncheck3">Checkbox 3</label>
                            </div>
                            <br />
                            <!-- Radio -->
                            <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
                              <input
                                type="radio"
                                class="btn-check"
                                name="btnradio"
                                id="btnradio1"
                                checked
                                autocomplete="off"
                              />
                              <label class="btn btn-outline-primary" for="btnradio1">Radio 1</label>
                              <input type="radio" class="btn-check" name="btnradio" id="btnradio2" autocomplete="off" />
                              <label class="btn btn-outline-primary" for="btnradio2">Radio 2</label>
                              <input type="radio" class="btn-check" name="btnradio" id="btnradio3" autocomplete="off" />
                              <label class="btn btn-outline-primary" for="btnradio3">Radio 3</label>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Button Group -->
                <div class="col-12">
                  <div class="card">
                    <h5 class="card-header">Button Group</h5>
                    <div class="card-body">
                      <div class="row g-4">
                        <div class="col-md-6">
                          <small class="text-light fw-semibold">Basic</small>
                          <div class="mt-3">
                            <div class="btn-group" role="group" aria-label="Basic example">
                              <button type="button" class="btn btn-secondary">Left</button>
                              <button type="button" class="btn btn-secondary">Middle</button>
                              <button type="button" class="btn btn-secondary">Right</button>
                            </div>
                          </div>
                        </div>
                        <div class="col-md-6">
                          <small class="text-light fw-semibold">Outline</small>
                          <div class="mt-3">
                            <div class="btn-group" role="group" aria-label="Basic example">
                              <button type="button" class="btn btn-outline-secondary">Left</button>
                              <button type="button" class="btn btn-outline-secondary">Middle</button>
                              <button type="button" class="btn btn-outline-secondary">Right</button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <hr class="m-0" />
                    <div class="card-body">
                      <div class="row">
                        <div class="col-xl-6 mb-xl-0 mb-3">
                          <small class="text-light fw-semibold">Button Toolbar</small>
                          <div
                            class="btn-toolbar demo-inline-spacing"
                            role="toolbar"
                            aria-label="Toolbar with button groups"
                          >
                            <div class="btn-group" role="group" aria-label="First group">
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-bell"></i>
                              </button>
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-task"></i>
                              </button>
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-check-shield"></i>
                              </button>
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-comment-dots"></i>
                              </button>
                            </div>
                            <div class="btn-group" role="group" aria-label="Second group">
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-bold"></i>
                              </button>
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-italic"></i>
                              </button>
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-underline"></i>
                              </button>
                            </div>
                            <div class="btn-group" role="group" aria-label="Third group">
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-volume-full"></i>
                              </button>
                            </div>
                          </div>
                        </div>
                        <div class="col-xl-6">
                          <small class="text-light fw-semibold">Button Nesting</small>
                          <div class="mt-3">
                            <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-car"></i>
                              </button>
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-rocket"></i>
                              </button>
                              <button type="button" class="btn btn-outline-secondary">
                                <i class="tf-icons bx bx-bulb"></i>
                              </button>
                              <div class="btn-group" role="group">
                                <button
                                  id="btnGroupDrop1"
                                  type="button"
                                  class="btn btn-outline-secondary dropdown-toggle"
                                  data-bs-toggle="dropdown"
                                  aria-haspopup="true"
                                  aria-expanded="false"
                                >
                                  Dropdown
                                </button>
                                <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
                                  <a class="dropdown-item" href="javascript:void(0);">Dropdown link</a>
                                  <a class="dropdown-item" href="javascript:void(0);">Dropdown link</a>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->
            
<?php include 'footer.php'; ?>